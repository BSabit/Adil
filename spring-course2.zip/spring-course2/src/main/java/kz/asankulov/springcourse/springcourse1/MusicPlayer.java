package kz.asankulov.springcourse.springcourse1;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Random;
import java.util.List;
@Component
public class MusicPlayer {
    private List <Music> musicList = new ArrayList<>();

    @Autowired
    MusicPlayer(List <Music> musicList){
        this.musicList = musicList;

    }


    public String playMusic(){
        Random random = new Random();
            Music genreList = musicList.get(random.nextInt(musicList.size()));
            List music = genreList.getSong();
            return music.get(random.nextInt(music.size())).toString();
    }
}

