package kz.asankulov.springcourse.springcourse1;

public enum Genre {
    ROCK,POP,RAP
}
