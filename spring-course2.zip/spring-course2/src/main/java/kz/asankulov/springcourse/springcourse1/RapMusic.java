package kz.asankulov.springcourse.springcourse1;

import java.util.ArrayList;
import java.util.List;

public class RapMusic implements Music{
    private String aLot = "21 Savage - a lot";
    private String tShirt = "Migos - T-shirt";
    private String rockStar = "Post Malone - RockStar";

    public String getaLot() {
        return aLot;
    }

    public String gettShirt() {
        return tShirt;
    }

    public String getRokStar() {
        return rockStar;
    }

    public List<String> getSong(){
        List<String>rapMusicList = new ArrayList<>();
        rapMusicList.add(aLot);
        rapMusicList.add(tShirt);
        rapMusicList.add(rockStar);
        return rapMusicList;
    }
}
