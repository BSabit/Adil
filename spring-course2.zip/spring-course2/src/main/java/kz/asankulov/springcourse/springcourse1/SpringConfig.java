package kz.asankulov.springcourse.springcourse1;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import java.util.Arrays;
import java.util.List;

@Configuration
@ComponentScan("kz.asankulov.springcourse.springcourse1")
public class SpringConfig {
    @Bean
    public PopMusic popMusic(){
        return new PopMusic();
    }
    @Bean
    public RockMusic rockMusic(){
        return new RockMusic();
    }
    @Bean
    public RapMusic rapMusic(){
        return new RapMusic();
    }
    @Bean
    public MusicPlayer musicPlayerList(){
        return new MusicPlayer(Arrays.asList(popMusic(),rockMusic(),rapMusic()));
    }
}
