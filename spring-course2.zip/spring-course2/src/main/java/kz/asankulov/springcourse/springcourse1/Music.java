package kz.asankulov.springcourse.springcourse1;

import java.util.List;

public interface Music {
    public List<String> getSong();
}
