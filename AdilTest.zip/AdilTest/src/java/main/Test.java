package java.main;

public class Test {
    static String a = "abc";
    static String b = "abcdef";
    public static String[] solution(String s) {
        StringBuilder sb = new StringBuilder(s);
        for ()
    }


}
